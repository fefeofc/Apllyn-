import { useEffect, useRef } from "react";

/** Single global atmosphere — particles, fog blobs, gradient mesh — sits fixed behind everything. */
export function Atmosphere() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current; if (!canvas) return;
    const ctx = canvas.getContext("2d"); if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let w = 0, h = 0, raf = 0;
    let mouseX = 0, mouseY = 0;

    const resize = () => {
      w = window.innerWidth; h = window.innerHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      canvas.style.width = `${w}px`; canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    const onMove = (e: MouseEvent) => {
      mouseX = e.clientX; mouseY = e.clientY;
    };
    window.addEventListener("mousemove", onMove);

    const COUNT = window.innerWidth < 768 ? 70 : 140;
    const parts = Array.from({ length: COUNT }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.15,
      vy: -Math.random() * 0.35 - 0.05,
      r: Math.random() * 1.4 + 0.3,
      a: Math.random() * 0.55 + 0.15,
      hue: 315 + Math.random() * 40,
      phase: Math.random() * Math.PI * 2,
    }));

    let t = 0;
    const tick = () => {
      t += 0.008;
      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = "lighter";

      for (const p of parts) {
        p.phase += 0.01;
        p.x += p.vx + Math.sin(p.phase) * 0.15;
        p.y += p.vy;
        // mouse parallax: subtle attraction
        const dx = (mouseX - p.x) * 0.00006;
        const dy = (mouseY - p.y) * 0.00006;
        p.x += dx * 30; p.y += dy * 30;

        if (p.y < -20) { p.y = h + 20; p.x = Math.random() * w; }
        if (p.x < -20) p.x = w + 20;
        if (p.x > w + 20) p.x = -20;

        const radius = p.r * 8;
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, radius);
        g.addColorStop(0, `hsla(${p.hue}, 100%, 70%, ${p.a})`);
        g.addColorStop(1, `hsla(${p.hue}, 100%, 60%, 0)`);
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.globalCompositeOperation = "source-over";
      raf = requestAnimationFrame(tick);
    };
    tick();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMove);
    };
  }, []);

  return (
    <>
      {/* fixed gradient mesh */}
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute -top-40 -left-32 h-[55vh] w-[55vh] rounded-full bg-[oklch(0.55_0.28_330/0.45)] blur-[120px] animate-drift" />
        <div className="absolute top-[30%] right-[-10%] h-[60vh] w-[60vh] rounded-full bg-[oklch(0.45_0.25_300/0.4)] blur-[140px] animate-float-slow" />
        <div className="absolute bottom-[10%] left-[20%] h-[50vh] w-[50vh] rounded-full bg-[oklch(0.5_0.27_340/0.35)] blur-[130px] animate-drift" style={{ animationDelay: "-4s" }} />
        <div className="absolute top-[60%] left-[-15%] h-[45vh] w-[45vh] rounded-full bg-[oklch(0.4_0.22_310/0.4)] blur-[130px] animate-float-slow" style={{ animationDelay: "-3s" }} />
      </div>
      {/* fixed particle canvas */}
      <canvas ref={ref} aria-hidden className="pointer-events-none fixed inset-0 z-0" />
      {/* vignette + noise top */}
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0"
        style={{ background: "radial-gradient(ellipse at center, transparent 40%, oklch(0.05 0.02 310 / 0.7) 100%)" }} />
    </>
  );
}
