import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { motion } from "framer-motion";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost";
  href?: string;
  icon?: ReactNode;
  children: ReactNode;
};

export const NeonButton = forwardRef<HTMLButtonElement, Props>(function NeonButton(
  { variant = "primary", href, icon, children, className = "", ...rest }, ref
) {
  const base = "group relative inline-flex items-center gap-2.5 rounded-full px-6 py-3 text-sm font-medium tracking-wide transition-all duration-300 overflow-hidden";
  const styles = variant === "primary"
    ? "text-white glow-pink hover:glow-pink-strong"
    : "glass text-foreground hover:border-[oklch(0.7_0.3_0/0.6)]";

  const inner = (
    <>
      {variant === "primary" && (
        <span className="absolute inset-0 bg-[linear-gradient(115deg,oklch(0.78_0.3_0),oklch(0.55_0.27_320),oklch(0.78_0.3_0))] bg-[length:200%_100%] animate-[shimmer_3s_linear_infinite]" />
      )}
      <span className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-[radial-gradient(circle_at_center,oklch(0.85_0.25_0/0.4),transparent_70%)]" />
      <span className="relative z-10">{children}</span>
      {icon && <span className="relative z-10 inline-flex h-6 w-6 items-center justify-center rounded-full bg-black/30 transition-transform duration-300 group-hover:translate-x-0.5">{icon}</span>}
    </>
  );

  const motionProps = { whileHover: { scale: 1.03 }, whileTap: { scale: 0.97 } } as const;

  if (href) {
    return (
      <motion.a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer" className={`${base} ${styles} ${className}`} {...motionProps}>
        {inner}
      </motion.a>
    );
  }
  return (
    <motion.button ref={ref} className={`${base} ${styles} ${className}`} {...motionProps} {...(rest as Record<string, unknown>)}>
      {inner}
    </motion.button>
  );
});
