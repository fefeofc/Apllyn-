import { createFileRoute } from "@tanstack/react-router";
import {
  motion,
  useScroll,
  useTransform,
  useSpring,
  useMotionValue,
  AnimatePresence,
} from "framer-motion";
import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  ArrowRight,
  Play,
  Brain,
  Cpu,
  MessageSquare,
  BarChart3,
  Sparkles,
  Zap,
  Linkedin,
  Instagram,
  Twitter,
  Send,
  Mail,
  Phone,
  MapPin,
  Menu,
  X,
  Quote,
  CheckCircle2,
  Star,
  ChevronRight,
} from "lucide-react";
import heroWoman from "@/assets/hero-ai-woman.jpg";
import centerpiece from "@/assets/centerpiece-3d.jpg";
import secondaryFace from "@/assets/secondary-face.jpg";
import logoMark from "@/assets/applyn-logo.png";
import { NeonButton } from "@/components/applyn/NeonButton";
import { TiltCard } from "@/components/applyn/TiltCard";
import { CountUp } from "@/components/applyn/CountUp";
import { Atmosphere } from "@/components/applyn/Atmosphere";

export const Route = createFileRoute("/")({ component: ApplynLanding });

const whatsappLink = "https://wa.me/5543996300552?text=Quero%20ajuda";

const nav = [
  { label: "Início", href: "#inicio" },
  { label: "Soluções", href: "#solucoes" },
  { label: "Como funciona", href: "#como-funciona" },
  { label: "Sobre", href: "#sobre" },
  { label: "Contato", href: "#contato" },
];

function Reveal({ children, delay = 0, y = 24, className = "" }: { children: ReactNode; delay?: number; y?: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });
  return (
    <motion.div
      className="fixed top-0 left-0 right-0 z-[100] h-[2px] origin-left"
      style={{ scaleX, background: "linear-gradient(90deg, oklch(0.78 0.3 0), oklch(0.6 0.28 330))" }}
    />
  );
}

function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const closeMenu = () => setMobileOpen(false);

  return (
    <>
      <header className="fixed top-0 inset-x-0 z-50 px-4 sm:px-8 pt-5">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className={`mx-auto max-w-7xl flex items-center justify-between rounded-full px-4 sm:px-6 py-3 transition-all duration-500 ${scrolled ? "glass shadow-[0_8px_40px_oklch(0_0_0/0.4)]" : "bg-transparent"}`}
        >
          <a href="#inicio" className="flex items-center gap-2 group">
            <img src={logoMark} alt="" className="h-7 w-7 drop-shadow-[0_0_8px_oklch(0.72_0.3_0/0.8)] transition-transform duration-300 group-hover:scale-110" />
            <span className="font-display text-lg tracking-tight">applyn</span>
          </a>

          <nav className="hidden md:flex items-center gap-7 text-sm text-muted-foreground">
            {nav.map((n, i) => (
              <a key={n.href} href={n.href}
                className={`relative py-1 transition-colors hover:text-foreground group ${i === 0 ? "text-[oklch(0.78_0.28_0)]" : ""}`}>
                {n.label}
                <span className="absolute inset-x-0 bottom-0 h-px bg-[oklch(0.78_0.28_0)] scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <NeonButton href={whatsappLink} icon={<ArrowRight className="h-3.5 w-3.5" />} className="hidden sm:inline-flex !py-2 !px-4 !text-xs">
              Fale conosco
            </NeonButton>
            <button onClick={() => setMobileOpen(v => !v)}
              className="md:hidden grid h-9 w-9 place-items-center rounded-full glass text-foreground" aria-label="Menu">
              <AnimatePresence mode="wait" initial={false}>
                {mobileOpen
                  ? <motion.span key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.2 }}><X className="h-4 w-4" /></motion.span>
                  : <motion.span key="menu" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.2 }}><Menu className="h-4 w-4" /></motion.span>
                }
              </AnimatePresence>
            </button>
          </div>
        </motion.div>
      </header>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-40 bg-[oklch(0.08_0.02_310/0.92)] backdrop-blur-xl flex flex-col items-center justify-center"
            onClick={closeMenu}
          >
            <motion.nav
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="flex flex-col items-center gap-6"
              onClick={e => e.stopPropagation()}
            >
              {nav.map((n, i) => (
                <motion.a key={n.href} href={n.href} onClick={closeMenu}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
                  className="font-display text-3xl font-semibold hover:text-[oklch(0.78_0.28_0)] transition-colors"
                >
                  {n.label}
                </motion.a>
              ))}
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: nav.length * 0.06 }} className="mt-4">
                <NeonButton href={whatsappLink} onClick={closeMenu}>Fale conosco</NeonButton>
              </motion.div>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const yImg = useTransform(scrollYProgress, [0, 1], [0, 160]);
  const scaleImg = useTransform(scrollYProgress, [0, 1], [1, 1.08]);
  const yText = useTransform(scrollYProgress, [0, 1], [0, -60]);
  const opacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 45, damping: 25 });
  const sy = useSpring(my, { stiffness: 45, damping: 25 });

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      mx.set((e.clientX / window.innerWidth - 0.5) * 30);
      my.set((e.clientY / window.innerHeight - 0.5) * 30);
    };
    window.addEventListener("mousemove", handler);
    return () => window.removeEventListener("mousemove", handler);
  }, [mx, my]);

  return (
    <section id="inicio" className="relative min-h-screen pt-28 pb-20 overflow-visible">
      <div ref={ref} className="relative mx-auto max-w-7xl px-4 sm:px-8 grid lg:grid-cols-[1.1fr_1fr] gap-10 items-center min-h-[85vh]">
        <motion.div style={{ y: yText, opacity }} className="relative z-20">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
            className="inline-flex items-center gap-2 text-[11px] font-medium tracking-[0.32em] text-[oklch(0.78_0.28_0)] uppercase">
            <span className="h-px w-8 bg-[oklch(0.78_0.28_0)]" /> Applyn · IA que transforma
          </motion.div>

          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="mt-5 font-display text-5xl sm:text-6xl lg:text-[4.5rem] font-semibold leading-[1.02]">
            Inteligência que <br />
            <span className="text-neon">impulsiona o futuro</span>
          </motion.h1>

          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="mt-6 text-base text-muted-foreground max-w-md leading-relaxed">
            Soluções de IA e automações inteligentes para empresas que querem crescer mais rápido, com menos esforço.
          </motion.p>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="mt-8 flex flex-wrap gap-3">
            <NeonButton href={whatsappLink}>Conheça nossas soluções</NeonButton>
            <NeonButton variant="ghost" href="#como-funciona" icon={<Play className="h-3 w-3 fill-current" />}>
              Ver como funciona
            </NeonButton>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.45, ease: [0.22, 1, 0.36, 1] }}
            className="mt-12 grid sm:grid-cols-2 gap-4 max-w-lg">
            {[
              { icon: <Zap className="h-4 w-4" />, t: "Automação inteligente", d: "Processos mais rápidos e sem erros." },
              { icon: <Sparkles className="h-4 w-4" />, t: "IA personalizada", d: "Soluções sob medida para o seu negócio." },
            ].map(f => (
              <div key={f.t} className="flex items-start gap-3 group">
                <div className="mt-0.5 grid h-10 w-10 flex-shrink-0 place-items-center rounded-xl border border-[oklch(0.5_0.2_320/0.25)] bg-[oklch(0.15_0.05_310/0.3)] backdrop-blur-sm transition-all duration-300 group-hover:border-[oklch(0.78_0.28_0/0.5)] group-hover:glow-pink">
                  <span className="text-[oklch(0.78_0.28_0)]">{f.icon}</span>
                </div>
                <div>
                  <div className="text-sm font-medium">{f.t}</div>
                  <div className="text-xs text-muted-foreground mt-0.5 max-w-[200px]">{f.d}</div>
                </div>
              </div>
            ))}
          </motion.div>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, delay: 0.65 }}
            className="mt-10 flex items-center gap-4">
            <div className="flex -space-x-2">
              {["oklch(0.65_0.2_0)", "oklch(0.55_0.25_310)", "oklch(0.6_0.22_330)", "oklch(0.5_0.2_300)"].map((c, i) => (
                <div key={i} className="h-8 w-8 rounded-full border-2 border-[oklch(0.08_0.02_310)] flex items-center justify-center text-xs font-bold"
                  style={{ background: `radial-gradient(circle at 35% 35%, white 0%, ${c.replace(/_/g, " ")} 100%)` }}>
                  {["A", "B", "C", "D"][i]}
                </div>
              ))}
            </div>
            <div className="text-xs text-muted-foreground">
              <span className="text-foreground font-medium">+30 empresas</span> já transformaram seus negócios
            </div>
          </motion.div>
        </motion.div>

        <motion.div style={{ y: yImg, scale: scaleImg, x: sx, translateY: sy }}
          className="relative z-10 lg:h-[720px] flex items-center justify-center">
          <div className="absolute inset-0 -z-10 flex items-center justify-center">
            <div className="h-[80%] w-[80%] rounded-full bg-[radial-gradient(circle,oklch(0.6_0.32_330/0.55),transparent_65%)] blur-3xl animate-pulse-glow" />
          </div>
          <motion.img src={heroWoman} alt="" width={1280} height={1280}
            className="relative w-[115%] max-w-none object-contain animate-breath mask-radial-fade blend-lighten"
            style={{ filter: "saturate(1.15) contrast(1.05)" }} />
          {[...Array(10)].map((_, i) => (
            <motion.span key={i} className="absolute rounded-sm bg-[oklch(0.78_0.3_0)]"
              style={{ height: `${4 + (i % 3) * 3}px`, width: `${4 + (i % 3) * 3}px`, top: `${10 + (i * 11) % 80}%`, left: `${(i * 17) % 90}%`, boxShadow: "0 0 14px oklch(0.78 0.3 0 / 0.95)" }}
              animate={{ y: [0, -25, 0], opacity: [0.2, 1, 0.2], rotate: [0, 200, 360] }}
              transition={{ duration: 6 + i * 0.4, repeat: Infinity, delay: i * 0.35, ease: "easeInOut" }} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}

function Marquee() {
  const items = Array.from({ length: 14 }, (_, i) => i);
  return (
    <div className="relative w-full overflow-hidden py-5 -rotate-2 select-none">
      <div className="absolute inset-0 bg-[linear-gradient(90deg,oklch(0.55_0.3_335),oklch(0.45_0.27_310),oklch(0.55_0.3_345))] opacity-90" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,oklch(0.85_0.2_0/0.4),transparent_70%)]" />
      <div className="relative flex animate-marquee gap-12 whitespace-nowrap text-2xl font-display font-semibold text-white">
        {[...items, ...items].map((i) => (
          <span key={i} className="flex items-center gap-3 opacity-90">
            <img src={logoMark} alt="" className="h-6 w-6 brightness-200" /> applyn
          </span>
        ))}
      </div>
    </div>
  );
}

function HowItWorks() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const rotate = useTransform(scrollYProgress, [0, 1], [-25, 70]);
  const y = useTransform(scrollYProgress, [0, 1], [80, -80]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.9, 1.05, 0.95]);

  const steps = [
    { n: "01", t: "Entendemos\no seu negócio", d: "Analisamos seus desafios e identificamos oportunidades para crescer.", perks: ["Diagnóstico gratuito", "Análise de processos"] },
    { n: "02", t: "Criamos a\nsolução ideal", d: "Desenvolvemos IA personalizada para resolver seus desafios específicos.", perks: ["Desenvolvimento ágil", "Aprovação em etapas"] },
    { n: "03", t: "Geramos resultados\nreais", d: "Mais eficiência, redução de custos e crescimento acelerado.", perks: ["Métricas em tempo real", "Suporte contínuo"] },
  ];

  return (
    <section id="como-funciona" className="relative py-32 overflow-visible">
      <div ref={ref} className="relative mx-auto max-w-7xl px-4 sm:px-8 text-center">
        <Reveal><div className="text-[11px] font-medium tracking-[0.32em] uppercase text-[oklch(0.78_0.28_0)]">Como funciona</div></Reveal>
        <Reveal delay={0.1}>
          <h2 className="mt-4 font-display text-4xl sm:text-5xl lg:text-6xl font-semibold leading-tight">
            Inteligência aplicada<br />em <span className="text-neon">3 passos</span>
          </h2>
        </Reveal>

        <div className="relative mt-24 grid lg:grid-cols-3 gap-12 lg:gap-4 items-start min-h-[440px]">
          <motion.div style={{ rotate, y, scale }}
            className="hidden lg:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[560px] h-[560px] items-center justify-center pointer-events-none">
            <div className="absolute inset-0 rounded-full bg-[radial-gradient(circle,oklch(0.6_0.32_330/0.55),transparent_60%)] blur-3xl animate-pulse-glow" />
            <motion.img src={centerpiece} alt="" width={1024} height={1024} loading="lazy"
              className="relative w-full h-full object-contain animate-float-slow mask-radial-soft blend-lighten"
              style={{ filter: "saturate(1.2) contrast(1.05)" }} />
          </motion.div>

          {steps.map((s, i) => (
            <Reveal key={s.n} delay={i * 0.15}>
              <div className={`relative ${i === 1 ? "lg:opacity-0 lg:pointer-events-none" : ""}`}>
                <div className="font-display text-8xl font-light text-transparent leading-none"
                  style={{ WebkitTextStroke: "1px oklch(0.78 0.28 0 / 0.85)" }}>
                  <CountUp to={parseInt(s.n, 10)} prefix="0" />
                </div>
                <h3 className="mt-5 font-display text-xl font-semibold whitespace-pre-line">{s.t}</h3>
                <p className="mt-3 text-sm text-muted-foreground max-w-[260px] mx-auto leading-relaxed">{s.d}</p>
                <ul className="mt-4 flex flex-col gap-1.5 items-center">
                  {s.perks.map(p => (
                    <li key={p} className="flex items-center gap-1.5 text-xs text-[oklch(0.78_0.28_0)]">
                      <CheckCircle2 className="h-3 w-3 flex-shrink-0" />{p}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="lg:hidden mt-12 relative w-full max-w-md mx-auto">
          <div className="absolute inset-0 rounded-full bg-[radial-gradient(circle,oklch(0.6_0.32_330/0.55),transparent_60%)] blur-3xl" />
          <img src={centerpiece} alt="" width={1024} height={1024} loading="lazy" className="relative animate-float-slow w-full mask-radial-soft blend-lighten" />
        </div>
      </div>
    </section>
  );
}

function Solutions() {
  const cards = [
    { icon: Brain, t: "Automação\nde Processos", d: "Elimine tarefas repetitivas e aumente a produtividade do seu time.", color: "oklch(0.65 0.28 25)", bg: "oklch(0.18 0.06 25 / 0.6)" },
    { icon: Cpu, t: "Inteligência\nArtificial", d: "IA personalizada para análise, previsão e tomada de decisão mais assertiva.", color: "oklch(0.65 0.28 310)", bg: "oklch(0.18 0.06 310 / 0.6)" },
    { icon: MessageSquare, t: "Chatbots &\nAtendimento", d: "Atendimento 24/7 com experiência incrível para seus clientes.", color: "oklch(0.65 0.28 340)", bg: "oklch(0.18 0.06 340 / 0.6)" },
    { icon: BarChart3, t: "Análise de\nDados", d: "Transforme dados em insights valiosos e impulsione seus resultados.", color: "oklch(0.65 0.28 0)", bg: "oklch(0.18 0.06 0 / 0.6)" },
  ];

  return (
    <section id="solucoes" className="relative py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-8 text-center">
        <Reveal><div className="text-[11px] font-medium tracking-[0.32em] uppercase text-[oklch(0.78_0.28_0)]">Soluções Applyn</div></Reveal>
        <Reveal delay={0.1}>
          <h2 className="mt-4 font-display text-4xl sm:text-5xl lg:text-6xl font-semibold leading-tight">
            Soluções inteligentes<br />para o <span className="text-neon">seu negócio</span>
          </h2>
        </Reveal>
        <Reveal delay={0.2}>
          <p className="mt-5 text-muted-foreground max-w-xl mx-auto">Tecnologia, estratégia e criatividade para transformar a forma como você trabalha e cresce.</p>
        </Reveal>

        <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-5" style={{ perspective: 1200 }}>
          {cards.map((c, i) => (
            <Reveal key={c.t} delay={i * 0.1}>
              <TiltCard className="h-full">
                <div className="group relative h-full rounded-2xl glass neon-border p-6 text-left transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_20px_60px_oklch(0_0_0/0.4)]">
                  <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{ background: `radial-gradient(circle at top left, ${c.color}22, transparent 60%)` }} />
                  <div className="relative">
                    <motion.div className="inline-flex h-12 w-12 items-center justify-center rounded-xl"
                      style={{ background: c.bg, color: c.color }}
                      animate={{ y: [0, -6, 0] }}
                      transition={{ duration: 4 + i * 0.3, repeat: Infinity, ease: "easeInOut" }}>
                      <c.icon className="h-5 w-5" />
                    </motion.div>
                    <h3 className="mt-6 font-display text-lg font-semibold whitespace-pre-line">{c.t}</h3>
                    <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{c.d}</p>
                    <a href={whatsappLink} className="mt-5 inline-flex items-center gap-2 text-sm font-medium group/link transition-colors" style={{ color: c.color }}>
                      Saiba mais
                      <span className="grid h-6 w-6 place-items-center rounded-full border transition-transform group-hover/link:translate-x-1" style={{ borderColor: `${c.color}80` }}>
                        <ArrowRight className="h-3 w-3" />
                      </span>
                    </a>
                  </div>
                </div>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Stats() {
  const stats = [
    { v: 50, p: "+", l: "Projetos\nEntregues" },
    { v: 30, p: "+", l: "Clientes\nAtendidos" },
    { v: 98, s: "%", l: "Satisfação\ndos Clientes" },
    { v: 24, s: "/7", l: "Suporte\nEspecializado" },
  ];

  return (
    <section id="sobre" className="relative py-32 overflow-visible">
      <div className="mx-auto max-w-7xl px-4 sm:px-8 grid lg:grid-cols-2 gap-16 items-center">
        <Reveal>
          <div className="relative h-[500px] lg:h-[620px]">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="h-[85%] w-[85%] rounded-full bg-[radial-gradient(circle,oklch(0.55_0.32_335/0.55),transparent_65%)] blur-3xl animate-pulse-glow" />
            </div>
            <img src={secondaryFace} alt="" width={1024} height={1024} loading="lazy"
              className="absolute inset-0 w-full h-full object-cover mask-radial-fade blend-lighten animate-breath"
              style={{ filter: "saturate(1.2) contrast(1.05)" }} />
            {[...Array(6)].map((_, i) => (
              <motion.span key={i} className="absolute h-1.5 w-1.5 rounded-full bg-[oklch(0.78_0.3_0)]"
                style={{ top: `${20 + (i * 14) % 60}%`, left: `${10 + (i * 17) % 80}%`, boxShadow: "0 0 12px oklch(0.78 0.3 0 / 0.9)" }}
                animate={{ y: [0, -20, 0], opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 5 + i, repeat: Infinity, delay: i * 0.5 }} />
            ))}
          </div>
        </Reveal>
        <div>
          <Reveal><div className="text-[11px] font-medium tracking-[0.32em] uppercase text-[oklch(0.78_0.28_0)]">Por que Applyn?</div></Reveal>
          <Reveal delay={0.1}>
            <h2 className="mt-4 font-display text-4xl sm:text-5xl font-semibold leading-tight">
              Mais que tecnologia,<br />parceria para <span className="text-neon">crescer</span>
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-5 text-sm text-muted-foreground max-w-md leading-relaxed">
              Somos uma equipe apaixonada por inovação e resultados. Nossa missão é tornar a tecnologia de ponta acessível para empresas de todos os tamanhos.
            </p>
          </Reveal>
          <div className="mt-10 grid grid-cols-2 gap-5">
            {stats.map((st, i) => (
              <Reveal key={st.l} delay={i * 0.1}>
                <div className="glass rounded-2xl p-5 border border-[oklch(0.5_0.15_330/0.15)] hover:border-[oklch(0.78_0.28_0/0.3)] transition-colors duration-300">
                  <div className="font-display text-3xl sm:text-4xl font-semibold text-[oklch(0.78_0.28_0)]">
                    {st.p ?? ""}<CountUp to={st.v} />{st.s ?? ""}
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground whitespace-pre-line leading-relaxed">{st.l}</div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const testimonials = [
    { name: "Ana Rodrigues", role: "CEO, TechFlow", avatar: "A", color: "oklch(0.65 0.25 25)", text: "A Applyn transformou completamente nossa operação. Automatizamos 80% dos processos manuais e nosso time agora foca no que realmente importa.", stars: 5 },
    { name: "Carlos Mendes", role: "Diretor de Operações, LogisBR", avatar: "C", color: "oklch(0.6 0.25 310)", text: "Implementamos o chatbot e em 2 semanas já tínhamos 94% de satisfação no atendimento ao cliente. O ROI foi imediato e surpreendente.", stars: 5 },
    { name: "Juliana Costa", role: "Fundadora, NutriSaas", avatar: "J", color: "oklch(0.62 0.25 340)", text: "Nossa análise de dados ficou 10x mais rápida. Tomamos decisões baseadas em dados reais agora — algo que parecia impossível antes da Applyn.", stars: 5 },
  ];

  return (
    <section className="relative py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-8">
        <Reveal className="text-center"><div className="text-[11px] font-medium tracking-[0.32em] uppercase text-[oklch(0.78_0.28_0)]">Depoimentos</div></Reveal>
        <Reveal delay={0.1} className="text-center">
          <h2 className="mt-4 font-display text-4xl sm:text-5xl font-semibold leading-tight">
            O que nossos <span className="text-neon">clientes dizem</span>
          </h2>
        </Reveal>

        <div className="mt-16 grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.12}>
              <TiltCard className="h-full">
                <div className="group relative h-full rounded-2xl glass neon-border p-7 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_20px_60px_oklch(0_0_0/0.35)]">
                  <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{ background: `radial-gradient(circle at top right, ${t.color}18, transparent 65%)` }} />
                  <div className="relative">
                    <Quote className="h-8 w-8 mb-4" style={{ color: t.color }} />
                    <p className="text-sm text-muted-foreground leading-relaxed">{t.text}</p>
                    <div className="mt-6 flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0"
                        style={{ background: `radial-gradient(circle at 35% 35%, white 0%, ${t.color} 100%)` }}>
                        {t.avatar}
                      </div>
                      <div>
                        <div className="text-sm font-medium">{t.name}</div>
                        <div className="text-xs text-muted-foreground">{t.role}</div>
                      </div>
                      <div className="ml-auto flex gap-0.5">
                        {Array.from({ length: t.stars }).map((_, s) => (
                          <Star key={s} className="h-3 w-3 fill-[oklch(0.78_0.28_0)] text-[oklch(0.78_0.28_0)]" />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section id="contato" className="relative py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-8">
        <Reveal>
          <div className="relative rounded-3xl glass neon-border overflow-hidden p-10 sm:p-14 grid lg:grid-cols-[1.2fr_1fr] gap-10 items-center">
            <div className="absolute -inset-px rounded-3xl bg-[radial-gradient(circle_at_70%_50%,oklch(0.5_0.28_330/0.3),transparent_60%)] pointer-events-none" />
            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[oklch(0.78_0.3_0/0.6)] to-transparent" />
            <div className="relative">
              <div className="text-[11px] font-medium tracking-[0.32em] uppercase text-[oklch(0.78_0.28_0)]">Pronto para o futuro?</div>
              <h2 className="mt-4 font-display text-4xl sm:text-5xl font-semibold leading-tight">
                Vamos transformar<br />sua empresa <span className="text-neon">juntos</span>
              </h2>
              <p className="mt-5 text-muted-foreground max-w-md">Fale com nosso time e descubra como a Applyn pode levar seu negócio para o próximo nível.</p>
              <ul className="mt-6 flex flex-col gap-2">
                {["Diagnóstico gratuito e sem compromisso", "Implementação rápida e suporte dedicado", "Resultados mensuráveis desde o primeiro mês"].map(b => (
                  <li key={b} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <ChevronRight className="h-3.5 w-3.5 text-[oklch(0.78_0.28_0)] flex-shrink-0" />{b}
                  </li>
                ))}
              </ul>
              <div className="mt-8 flex flex-wrap gap-3">
                <NeonButton href={whatsappLink}>Falar com especialista</NeonButton>
                <NeonButton variant="ghost" href="#solucoes" icon={<ArrowRight className="h-3 w-3" />}>Ver soluções</NeonButton>
              </div>
            </div>
            <div className="relative grid place-items-center h-72 lg:h-80">
              <div className="absolute inset-0 grid place-items-center">
                {[1, 2, 3, 4].map(r => (
                  <motion.div key={r} className="absolute rounded-full border border-[oklch(0.7_0.3_0/0.3)]"
                    style={{ width: `${r * 120}px`, height: `${r * 120}px` }}
                    animate={{ scale: [1, 1.12, 1], opacity: [0.5, 0.08, 0.5] }}
                    transition={{ duration: 3 + r * 0.7, repeat: Infinity, ease: "easeInOut", delay: r * 0.4 }} />
                ))}
              </div>
              <motion.div className="relative grid h-32 w-32 place-items-center rounded-full glass glow-pink-strong"
                animate={{ y: [0, -12, 0] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}>
                <img src={logoMark} alt="" className="h-16 w-16 drop-shadow-[0_0_18px_oklch(0.78_0.3_0)]" />
              </motion.div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="relative mt-12 border-t border-[oklch(0.5_0.15_320/0.2)]">
      <div className="mx-auto max-w-7xl px-4 sm:px-8 py-14 grid md:grid-cols-5 gap-10 text-sm">
        <div className="md:col-span-2">
          <a href="#inicio" className="flex items-center gap-2 group">
            <img src={logoMark} alt="" className="h-7 w-7 transition-transform duration-300 group-hover:scale-110" />
            <span className="font-display text-lg">applyn</span>
          </a>
          <p className="mt-4 text-muted-foreground max-w-xs leading-relaxed text-xs">
            Inteligência que impulsiona o futuro. Soluções de IA e automação para empresas que querem mais.
          </p>
          <div className="mt-6">
            <p className="text-xs font-medium mb-2">Receba novidades sobre IA</p>
            <div className="flex gap-2">
              <input type="email" placeholder="seu@email.com"
                className="flex-1 min-w-0 rounded-full glass px-4 py-2 text-xs outline-none border-transparent focus:border-[oklch(0.78_0.28_0/0.5)] transition-colors placeholder:text-muted-foreground/50" />
              <button className="grid h-9 w-9 place-items-center rounded-full bg-[oklch(0.72_0.28_0)] text-white hover:glow-pink transition-all duration-300 hover:scale-105 flex-shrink-0">
                <Send className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
        <div>
          <div className="font-medium mb-4">Navegação</div>
          <ul className="space-y-2 text-muted-foreground">
            {nav.map(n => (
              <li key={n.href}>
                <a href={n.href} className="hover:text-[oklch(0.78_0.28_0)] transition-colors flex items-center gap-1 group text-xs">
                  <ChevronRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-all -ml-3 group-hover:ml-0" />{n.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <div className="font-medium mb-4">Soluções</div>
          <ul className="space-y-2 text-muted-foreground text-xs">
            {["Automação de Processos", "Inteligência Artificial", "Chatbots & Atendimento", "Análise de Dados"].map(s => (
              <li key={s} className="hover:text-[oklch(0.78_0.28_0)] transition-colors cursor-pointer">{s}</li>
            ))}
          </ul>
        </div>
        <div>
          <div className="font-medium mb-4">Contato</div>
          <ul className="space-y-2.5 text-muted-foreground text-xs">
            <li className="flex items-center gap-2 hover:text-foreground transition-colors"><Mail className="h-3.5 w-3.5 flex-shrink-0" /><span>contato@applyn.com</span></li>
            <li className="flex items-center gap-2 hover:text-foreground transition-colors"><Phone className="h-3.5 w-3.5 flex-shrink-0" /><span>(11) 99999-9999</span></li>
            <li className="flex items-center gap-2 hover:text-foreground transition-colors"><MapPin className="h-3.5 w-3.5 flex-shrink-0" /><span>São Paulo, SP</span></li>
          </ul>
          <div className="mt-5 flex gap-2">
            {[Linkedin, Instagram, Twitter, Send].map((Ic, i) => (
              <a key={i} href={whatsappLink} aria-label="social"
                className="grid h-9 w-9 place-items-center rounded-full glass transition-all hover:glow-pink hover:-translate-y-0.5 hover:text-[oklch(0.78_0.28_0)] hover:scale-110">
                <Ic className="h-3.5 w-3.5" />
              </a>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-[oklch(0.5_0.15_320/0.15)] py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Applyn. Todos os direitos reservados. Feito com ❤️ e IA.
      </div>
    </footer>
  );
}

function ApplynLanding() {
  return (
    <main className="relative min-h-screen text-foreground overflow-x-hidden">
      <ScrollProgress />
      <Atmosphere />
      <div className="relative z-10">
        <Navbar />
        <Hero />
        <Marquee />
        <HowItWorks />
        <Solutions />
        <Stats />
        <Testimonials />
        <FinalCTA />
        <Footer />
      </div>
    </main>
  );
}
